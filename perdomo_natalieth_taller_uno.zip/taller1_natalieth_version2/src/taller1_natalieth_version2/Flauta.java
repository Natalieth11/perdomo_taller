package taller1_natalieth_version2;

import processing.core.PApplet;

public class Flauta {
	private PApplet app;
	private int x;
	private int y;
	private int c;
	private int tam;
	
	public Flauta(PApplet app, int x, int y) {
	this.app=app;
	this.x=x;
	this.y=y;
	tam=15;
	c=app.color(50, 55, 100);
	}
	
	public void pintar1() {
	//app.fill(255, 204, 0);
	//app.rect(300, 500, 200, 30);
	app.fill(c);
	app.ellipse(x, y, tam, tam);	
	}
	
	public void pintar2() {
	//app.fill(255, 204, 0);
	//app.rect(300, 500, 200, 30);
	app.fill(0);
	app.ellipse(x, y, tam, tam);	
	}
	
	

}
