package taller1_natalieth_version2;

import java.util.ArrayList;

import processing.core.PApplet;

public class Logica {
	private PApplet app;
	// creo arreglo donde guardare texto
	private String[] fragmento;
	// creo una copia 
	 private String[] copiaFrag;
	 //un arraylist donde gaurdare las taclas
	 private ArrayList<Piano> teclas;
	 //variable tipo piano
	 private Piano piano;
	 //prueba2
	 private boolean cambio;
	 //prueba 4
	 private int num;
	 //arraylist de circulos Flauta
	 private ArrayList<Flauta> circulos;
	 //variable del swicth
	 private int num1;
	 private boolean valid;
	
	public Logica(PApplet app) {
		
		this.app=app;
		//cargo el archivo de texto
		fragmento=app.loadStrings("texttoBase.txt");
		//inicializo 
		teclas = new ArrayList<Piano>();
		copiaFrag = new String[1];
		//prueba2
		cambio=false;
		//prueba 4
		num=0;
		//iicializo circulos
		circulos = new ArrayList<Flauta>();
		//inicializo switch de Flauta
		num1=0;
		valid=false;
		
		
		
		//hago una copia en donde hare las modificaciones que se me mostraran en un nuevo txt
		copiaFrag[0]=fragmento[0];
		
		
		
		
		
		//me divide por cada vez que me aparece la palabra una y se me guarda en un arreglo
		//esto es lo que seria el metodo interpretarUna
		String [] hh = copiaFrag[0].split("una");
		for (int i = 0; i < hh.length-1; i++) {	
        //se me pinta conforme a la cantidad que hay en ese arreglo 				
		teclas.add(new Piano(app, 100 + (i * 40), 100));	
	}	
	System.out.println(hh.length-1);
	
	
	
	//aqui voy a hacer los mismo para pintar los circulos de flauta
	String[] cir = copiaFrag[0].split(",");
	for (int e = 0; e < cir.length; e++) {
	circulos.add( new Flauta (app, 300 + (e*20),515));	
	}
	System.out.println(cir.length-1);
	


    }
	public void zonaSensiblePiano() {
	if(app.mouseX>100 && app.mouseX<460 && app.mouseY>100 && app.mouseY<180) {	
	cambio=!cambio;	
	}
	}
	
	public void click() {
	if(cambio==true) { num=1;
	copiaFrag[0] = copiaFrag[0].replace("una","1");
	System.out.println(copiaFrag[0]);
	
	}
	}
	
	public void teclaFlauta() {
		if(app.keyCode=='C') {
		num1=1;	
		valid=true;
		}	
	}
	
	public void reemplazarComas() {
		if(valid==true) {
		copiaFrag[0] = copiaFrag[0].replace(",","-");
		System.out.println(copiaFrag[0]);}	
	}
	
	public void pintarPiano() {
		switch(num) {
		case 0:
		for (int i = 0; i < teclas.size(); i++) {
			teclas.get(i).pintar();
		}
		
		for (Piano rect : teclas) {
			
			rect.pintar();
		}
		break;
		case 1:
			for (int i = 0; i < teclas.size(); i++) {
				teclas.get(i).pintar2();
			}
			
			for (Piano rect : teclas) {
				
				rect.pintar2();
			}	
			
			
		break;	
		}
	}
	
	public void pintarFlauta() {
		switch(num1) {
		case 0:
		for (int e = 0; e < circulos.size(); e++) {
			app.fill(255, 204, 0);
			app.rect(280, 500, 320, 30);
			circulos.get(e).pintar1();
		}
		
		for (Flauta uno : circulos) {
			
			uno.pintar1();
		}
		break;
		case 1:
			for (int e = 0; e < circulos.size(); e++) {
				app.fill(255, 204, 0);
				app.rect(280, 500, 320, 30);
				circulos.get(e).pintar2();
			}
			
			for (Flauta dos : circulos) {
				
				dos.pintar2();
			}	
			
			
		break;	
		}	
	}
	

}