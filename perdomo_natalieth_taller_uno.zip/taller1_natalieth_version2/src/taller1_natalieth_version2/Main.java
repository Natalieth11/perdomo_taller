package taller1_natalieth_version2;

import processing.core.PApplet;



public class Main extends PApplet {
	
	private Logica logica;

	public static void main(String[] args) {

		PApplet.main("taller1_natalieth_version2.Main");
	}
	public void settings() {
		size(1200, 700);
	}
	public void setup() {
		logica = new Logica (this);	
	}
	public void draw() {
		background(255);
		logica.pintarPiano();
	    logica.zonaSensiblePiano();
	    logica.pintarFlauta();
	}
	public void mouseDragged() {
			}
	
	public void mouseClicked() {
		logica.click();
		
	}

	public void mouseReleased() {
	
	}
	
	public void keyPressed() {
	logica.teclaFlauta();
	}
	

}
