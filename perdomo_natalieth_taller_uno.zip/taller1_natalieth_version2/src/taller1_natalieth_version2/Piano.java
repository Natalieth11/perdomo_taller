package taller1_natalieth_version2;

import java.awt.Color;

import processing.core.PApplet;

public class Piano {
	
	private PApplet app;
	private int x;
	private int y;
	private int c;
	private int tamX;
	private int tamY;

	public Piano(PApplet app, int x, int y) {
		this.app = app;
		this.x =x;
		this.y = y;
		tamX = 40;
		tamY = 80;
		c= app.color(app.random(0, 255), app.random(0, 255), app.random(0, 255));
		
	}
	
	public void pintar() {
		
		
		app.noFill();
		app.strokeWeight(5);
		app.stroke(100, 100, 100);
		app.rect(x, y, tamX, tamY);
		app.noStroke();
		
	}
	
	public void pintar2() {
		app.strokeWeight(5);
		app.stroke(100, 100, 100);
		app.fill(c);
		app.rect(x, y, tamX, tamY);	
	}
	

}
